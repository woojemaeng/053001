
import streamlit as st
import pandas as pd
import numpy as np

st.set_page_config(page_title="Streamlit Starter", page_icon="🧪", layout="wide")

st.title("🧪 Streamlit Starter")
st.markdown("작게 시작해서 빠르게 만들어보는 **스트림릿 앱** 템플릿입니다. 좌측 사이드바에서 페이지를 이동하세요.")

# --- Sidebar ---
st.sidebar.header("Settings")
theme = st.sidebar.selectbox("테마(시각적)", ["Light", "Dark", "System"], index=2)
st.sidebar.info("상단의 ··· 메뉴 → 'Always rerun' 켜면 개발이 더 편해요.")

# --- Data Loader with cache ---
@st.cache_data
def load_sample(n: int = 100):
    rng = np.random.default_rng(42)
    dates = pd.date_range("2025-01-01", periods=n, freq="D")
    df = pd.DataFrame({
        "date": dates,
        "value": rng.normal(loc=0, scale=1, size=n).cumsum()
    })
    return df

st.subheader("📄 CSV 업로드 또는 샘플 데이터")
uploaded = st.file_uploader("CSV 파일을 올리면 자동으로 미리보기와 차트를 그려요.", type=["csv"])

if uploaded:
    df = pd.read_csv(uploaded)
    st.session_state["df"] = df
    st.success(f"업로드 완료: {uploaded.name} | shape={df.shape}")
else:
    df = load_sample()
    st.session_state["df"] = df
    st.caption("샘플 데이터 사용 중 (캐시됨).")

# --- Preview ---
st.write("데이터 미리보기")
st.dataframe(df.head(20), use_container_width=True)

st.write("간단한 라인 차트")
st.line_chart(df.set_index(df.columns[0]))

st.markdown("---")
st.markdown("다음 페이지에서 **대시보드**, **폼/입력** 예시를 볼 수 있어요.")
