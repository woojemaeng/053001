
import streamlit as st
from datetime import datetime

st.title("📝 Form / Input 예시")
st.caption("폼으로 입력받아 상태에 저장하고 테이블로 보여줍니다.")

if "notes" not in st.session_state:
    st.session_state["notes"] = []

with st.form("note_form", clear_on_submit=True):
    title = st.text_input("제목", placeholder="메모 제목")
    detail = st.text_area("내용", placeholder="여기에 입력...")
    submitted = st.form_submit_button("저장")
    if submitted:
        if not title:
            st.warning("제목은 필수입니다.")
        else:
            st.session_state["notes"].append({
                "time": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
                "title": title,
                "detail": detail
            })
            st.success("저장했어요!")

st.write("현재 메모")
if st.session_state["notes"]:
    st.table(st.session_state["notes"])
else:
    st.info("아직 메모가 없어요.")
