
import streamlit as st
import pandas as pd

st.title("📈 Dashboard")
st.caption("업로드/샘플 데이터를 활용해 간단한 분석 위젯을 보여줍니다.")

df = st.session_state.get("df")
if df is None:
    st.warning("먼저 Home에서 데이터를 로드하세요.")
    st.stop()

# Numeric column pickers
numeric_cols = df.select_dtypes(include="number").columns.tolist()
if not numeric_cols:
    st.error("숫자 컬럼이 없어 차트를 만들 수 없어요.")
    st.stop()

xcol = st.selectbox("X축 (index로 사용)", options=df.columns, index=0)
ycol = st.selectbox("Y축 (값)", options=numeric_cols, index=0)

# Filter
with st.expander("필터"):
    n = st.slider("최근 N개만 보기", min_value=10, max_value=min(365, len(df)), value=min(100, len(df)))
    df_view = df.tail(n)
st.write(f"표시 중: 최근 {len(df_view)}개 행")

# Charts
st.line_chart(df_view.set_index(xcol)[ycol])

# KPIs
col1, col2, col3 = st.columns(3)
col1.metric("현재값", f"{df_view[ycol].iloc[-1]:.2f}")
col2.metric("최솟값", f"{df_view[ycol].min():.2f}")
col3.metric("최댓값", f"{df_view[ycol].max():.2f}")
